#!/system/bin/sh
# ============================================================
# REDMI K90 Pro Max 音质优化 — post-fs-data
# ============================================================

MODDIR=${0%/*}
LOG="/data/local/tmp/k90pm_audio.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [post-fs-data] $1" >> "$LOG"; }

echo "" > "$LOG"
log "启动"

# ── Root 环境检测 ──
ROOT_TYPE="unknown"
[ -d "/proc/sukisu" ] && ROOT_TYPE="sukisu"
[ "$ROOT_TYPE" = "unknown" ] && { [ -f "/data/adb/ksud" ] || [ -x "/data/adb/ksu/bin/ksud" ]; } && ROOT_TYPE="kernelsu"
[ "$ROOT_TYPE" = "unknown" ] && [ -d "/data/adb/magisk" ] && ROOT_TYPE="magisk"

RESETPROP=""
for rp in "/data/adb/magisk/resetprop" "/data/adb/ksu/bin/resetprop" "/data/adb/ap/bin/resetprop"; do
  [ -x "$rp" ] && { RESETPROP="$rp"; break; }
done
[ -z "$RESETPROP" ] && command -v resetprop >/dev/null 2>&1 && RESETPROP="resetprop"
log "Root: $ROOT_TYPE / resetprop: ${RESETPROP:-不可用}"

# ── OTA 检测 ──
SAVED_VER=""
[ -f "$MODDIR/system_version" ] && SAVED_VER=$(cat "$MODDIR/system_version")
CUR_VER=$(getprop ro.build.display.id)
if [ -n "$SAVED_VER" ] && [ "$SAVED_VER" != "$CUR_VER" ]; then
  log "OTA: $SAVED_VER → $CUR_VER，清除缓存"
  rm -rf "$MODDIR/work/volume" "$MODDIR/work/dolby" "$MODDIR/work/lp"
  echo "$CUR_VER" > "$MODDIR/system_version"
fi

# ── SELinux 上下文 ──
for f in "$MODDIR"/system/vendor/etc/*.xml "$MODDIR"/vendor/etc/*.xml "$MODDIR"/Link/odm/etc/*.xml; do
  [ -f "$f" ] && chcon u:object_r:vendor_configs_file:s0 "$f" 2>/dev/null
done
log "SELinux 上下文已设置"

# ── 早期 resetprop（音频服务启动前） ──
set_prop() {
  local key="$1" value="$2"
  if [ -n "$RESETPROP" ]; then
    "$RESETPROP" "$key" "$value" 2>/dev/null
  else
    setprop "$key" "$value" 2>/dev/null
  fi
}

if [ -n "$RESETPROP" ]; then
  for s in media alarm system vc_call ring notification tts fm; do
    set_prop ro.config.${s}_vol_steps 16
  done
  set_prop ro.config.media_vol_default 10
  set_prop ro.config.safe_media_volume_state 1
  set_prop ro.config.safe_media_volume 0
  set_prop ro.config.low_volume false
  set_prop ro.config.enable_audio_effects 1
  set_prop ro.vendor.audio.speaker.protect false
  set_prop ro.vendor.dolby.dap_bypassed_on_tiny_volume false
  set_prop persist.vendor.audio.low_power false
  set_prop persist.vendor.audio_hal.low_power false
  set_prop persist.vendor.audio.power.save.enable 0
  log "早期 resetprop 完成"
else
  setprop persist.vendor.audio.low_power false 2>/dev/null
  setprop persist.vendor.audio_hal.low_power false 2>/dev/null
  setprop persist.vendor.audio.power.save.enable 0 2>/dev/null
  log "resetprop 不可用，由 system.prop 兜底"
fi

# ── bind_tree：Dolby 调音文件挂载 ──
bind_tree() {
  local src_root="$1"
  local dst_root="$2"
  [ -d "$src_root" ] || return 0
  find "$src_root" -type f | while IFS= read -r src; do
    rel="${src#$src_root/}"
    dst="${dst_root%/}/$rel"
    [ -e "$dst" ] || continue
    mount --bind "$src" "$dst"
    restorecon "$dst" 2>/dev/null
  done
}

bind_tree "$MODDIR/Link" "/"
bind_tree "$MODDIR/vendor" "/vendor"

# ── V4A AIDL: 建 SHM 共享内存(参数持久化,APP退出后效果仍生效) ──
SHM_DIR=/data/local/tmp/v4a
SHM_STATUS=$SHM_DIR/shm_status.bin
SHM_HP=$SHM_DIR/shm_hp.bin
SHM_SPK=$SHM_DIR/shm_spk.bin
STATUS_SIZE=256
PARAM_SIZE=32784
mkdir -p $SHM_DIR/hp $SHM_DIR/spk
chmod 777 $SHM_DIR $SHM_DIR/hp $SHM_DIR/spk
chcon u:object_r:shell_data_file:s0 $SHM_DIR $SHM_DIR/hp $SHM_DIR/spk 2>/dev/null
[ -f "$SHM_STATUS" ] || { dd if=/dev/zero of=$SHM_STATUS bs=$STATUS_SIZE count=1 2>/dev/null; }
[ -f "$SHM_HP" ] || { dd if=/dev/zero of=$SHM_HP bs=$PARAM_SIZE count=1 2>/dev/null; }
[ -f "$SHM_SPK" ] || { dd if=/dev/zero of=$SHM_SPK bs=$PARAM_SIZE count=1 2>/dev/null; }
chmod 666 $SHM_STATUS $SHM_HP $SHM_SPK
chcon u:object_r:shell_data_file:s0 $SHM_STATUS $SHM_HP $SHM_SPK 2>/dev/null
log "V4A SHM 共享内存就绪: $(ls $SHM_DIR 2>/dev/null | wc -l) 项"

# ── 移除系统音量限制 ──
f="/odm/etc/audio/audio_lowpower_app_list.xml"
[ -f "$f" ] && mount --bind "$MODDIR/work/lp/audio_lowpower_app_list.xml" "$f"
log "post-fs-data 完成"