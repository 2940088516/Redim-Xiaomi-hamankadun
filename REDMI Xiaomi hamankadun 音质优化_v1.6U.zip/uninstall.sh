#!/system/bin/sh
# ============================================================
# REDMI K90 Pro Max 音质优化 Ultra v2.0 — 卸载清理（v2.1 优化版）
# 功能：停止守护进程 / 清理 SHM 与全部运行残留 / 还原属性
# ============================================================

LOG="/data/local/tmp/k90pm_audio.log"
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [uninstall] $1" >> "$LOG"; }
log "========== 开始卸载 =========="

CLEAN_ROOT="/data/local/tmp"

# ── 1. 停止全部后台/守护进程 ──
log "---------- 停止守护进程 ----------"
for svc in per_device_volume adaptive_volume volume_monitor bass_watchdog; do
  pids=$(pgrep -f "${svc}.sh" 2>/dev/null)
  if [ -n "$pids" ]; then
    for p in $pids; do
      kill "$p" 2>/dev/null
      log "  ✓ 已停止: ${svc}.sh (PID: $p)"
    done
  fi
done
# 兜底：模块目录下所有 sh 后台任务
for sh in /data/adb/*/modules/k90pm_audio_plus/system/etc/*.sh \
          /data/adb/*/modules/k90pm_audio_plus/bass_watchdog.sh; do
  [ -f "$sh" ] || continue
  bn=$(basename "$sh")
  pids=$(pgrep -f "$bn" 2>/dev/null)
  [ -n "$pids" ] && for p in $pids; do kill "$p" 2>/dev/null; done
done
sleep 1

# ── 2. 清理 V4A SHM 共享内存目录（含退出快照） ──
log "---------- 清理 V4A SHM ----------"
rm -rf "$CLEAN_ROOT/v4a" 2>/dev/null && log "  ✓ 已清理 $CLEAN_ROOT/v4a/（SHM 参数与快照）"

# ── 3. 清理 DAX3 / EQ 快照与运行数据 ──
log "---------- 清理运行数据 ----------"
rm -f "$CLEAN_ROOT/k90pm_dax3_snapshot.json" 2>/dev/null
rm -f "$CLEAN_ROOT/k90pm_eq_current.json" 2>/dev/null
rm -f "$CLEAN_ROOT/k90pm_eq_presets.json" 2>/dev/null
rm -f "$CLEAN_ROOT/k90pm_eq_active_preset" 2>/dev/null
rm -f "$CLEAN_ROOT/k90pm_eq_temp_gl" 2>/dev/null
rm -f "$CLEAN_ROOT/k90pm_wp_choice" 2>/dev/null
rm -f "$CLEAN_ROOT/k90pm_mode_choice" 2>/dev/null
rm -rf "$CLEAN_ROOT/k90pm_audio_work" 2>/dev/null
rm -rf "$CLEAN_ROOT/k90pm_audio_devices" 2>/dev/null
rm -rf "$CLEAN_ROOT/k90pm_dolby_fix" 2>/dev/null
rm -rf "$CLEAN_ROOT/k90pm_lp_fix" 2>/dev/null
rm -f "$CLEAN_ROOT/k90pm_audio_done" 2>/dev/null
rm -f "$CLEAN_ROOT/k90_audio.log" 2>/dev/null
rm -f "$CLEAN_ROOT/k90_audio_done" 2>/dev/null
rm -f "$CLEAN_ROOT/k90pm_audio.log" 2>/dev/null
rm -f "$CLEAN_ROOT/k90pm_eq.log" 2>/dev/null

# ── 4. 清理 V4A / 模块相关日志 ──
log "---------- 清理日志 ----------"
rm -f "$CLEAN_ROOT/v4a_recover.log" 2>/dev/null
rm -f "$CLEAN_ROOT/viper_install.log" 2>/dev/null
rm -f "/data/adb/viper_install.log" 2>/dev/null
rm -f "/data/adb/k90pm_audio.log" 2>/dev/null

# ── 5. 还原受控的系统属性 ──
log "---------- 还原系统属性 ----------"
RESETPROP=""
for rp in "/data/adb/magisk/resetprop" "/data/adb/ksu/bin/resetprop" "/data/adb/ap/bin/resetprop"; do
  [ -x "$rp" ] && { RESETPROP="$rp"; break; }
done
command -v resetprop >/dev/null 2>&1 && [ -z "$RESETPROP" ] && RESETPROP="resetprop"

if [ -n "$RESETPROP" ]; then
  "$RESETPROP" --delete persist.vendor.dolby.global.enable 2>/dev/null
  "$RESETPROP" --delete persist.vendor.dolby.dialog.enhancer.enable 2>/dev/null
  "$RESETPROP" --delete persist.vendor.dolby.volume.leveler.enable 2>/dev/null
  "$RESETPROP" --delete persist.vendor.dolby.virtualizer.enable 2>/dev/null
  "$RESETPROP" --delete persist.vendor.dolby.bass.enable 2>/dev/null
  "$RESETPROP" --delete persist.vendor.dolby.spectral.enable 2>/dev/null
  log "  ✓ 已清除 Dolby 模块属性覆盖"
else
  log "  ! 未找到 resetprop，跳过属性还原"
fi

# ── 6. 清理模块自带临时工作目录 ──
log "---------- 清理模块工作目录 ----------"
if [ -n "$MODDIR" ] && [ -d "$MODDIR/work" ]; then
  rm -rf "$MODDIR/work" 2>/dev/null
  log "  ✓ 已清理 $MODDIR/work/"
fi
rm -f /data/system/*per_app_volume*.xml 2>/dev/null

log "========== 卸载完成，请重启手机生效 =========="