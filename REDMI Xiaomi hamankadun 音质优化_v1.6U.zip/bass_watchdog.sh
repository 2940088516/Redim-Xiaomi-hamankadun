#!/system/bin/sh
# ============================================================
# K90PM 扬声器满血档守护
# 满血参数写死在 mixer_paths_canoe_mtp.xml：
#   SA1=100 RX0=96 RX1=96 RX2=120（系统切路由自动恢复满血）
# 本守护只负责两件事：
#   1) 音量达到最大档(>=15) -> tinymix 降到安全档防爆
#   2) 非最大档 -> 主动写回满血（兜底，防止降档值被路由滞留/时序错乱）
# 每3秒轮询一次（防止降档值被系统路由重建冲回满血）。
# K90PM音质优化模块 by 016.
# ============================================================

LOG="/data/local/tmp/k90pm_audio.log"
PID_FILE="/data/local/tmp/k90pm_bass_watchdog.pid"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [bass_watchdog] $1" >> "$LOG"; }

# 防止重复启动
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE" 2>/dev/null)
    [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null && exit 0
fi
echo $$ > "$PID_FILE"
cleanup() { rm -f "$PID_FILE" 2>/dev/null; exit 0; }
trap cleanup EXIT TERM INT

TM="/system/bin/tinymix"
VOL_THRESHOLD=15

# 满血档（与 mixer_paths 写死值一致）
apply_full() {
    "$TM" "SA1 FU21 Stereo Gain Offset dB" 100 2>/dev/null
    "$TM" "RX_RX0 Digital Volume" 96 2>/dev/null
    "$TM" "RX_RX1 Digital Volume" 96 2>/dev/null
    "$TM" "RX_RX2 Digital Volume" 120 2>/dev/null
    "$TM" 291 0 0 0 2>/dev/null
}

# 安全档（音量达到阈值时启用：降低增益、防削顶保护）
apply_safe() {
    "$TM" "SA1 FU21 Stereo Gain Offset dB" 96 2>/dev/null
    "$TM" "RX_RX0 Digital Volume" 90 2>/dev/null
    "$TM" "RX_RX1 Digital Volume" 90 2>/dev/null
    "$TM" "RX_RX2 Digital Volume" 96 2>/dev/null
    "$TM" 291 0 0 0 2>/dev/null
}

get_volume() {
    settings get system volume_music_speaker 2>/dev/null
}

log "启动（阈值=$VOL_THRESHOLD）"

# 首次立即执行一次初始化
CUR_VOL=$(get_volume)
if [ -n "$CUR_VOL" ] && [ "$CUR_VOL" -ge "$VOL_THRESHOLD" ] 2>/dev/null; then
    apply_safe
    log "初始音量=$CUR_VOL -> 安全档"
else
    apply_full
    log "初始音量=$CUR_VOL -> 满血档"
fi

while true; do
    sleep 3
    CUR_VOL=$(get_volume)
    [ -z "$CUR_VOL" ] && continue
    if [ "$CUR_VOL" -ge "$VOL_THRESHOLD" ] 2>/dev/null; then
        apply_safe
    else
        apply_full
    fi
done