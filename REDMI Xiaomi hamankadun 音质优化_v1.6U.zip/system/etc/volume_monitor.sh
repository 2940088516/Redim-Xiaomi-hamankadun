#!/system/bin/sh
LOG=/data/local/tmp/k90pm_audio.log
VOL_DIR=/data/local/tmp/ios_volume_devices
STATE_FILE=/data/local/tmp/ios_volume_adaptive_state
MONITOR_CONF=/data/local/tmp/ios_volume_monitor.conf
mkdir -p $VOL_DIR

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [monitor] $1" >> $LOG; }

load_config() {
  BT_MAX_VOL=14
  BT_DEFAULT_VOL=8
  HS_MAX_VOL=14
  ADAPTIVE_ENABLED=1
  QUIET_START=23
  QUIET_END=7
  FADE_MS=60
  v=$(settings get system ios_vol_bt_max 2>/dev/null)
  [ -n "$v" ] && [ "$v" != "null" ] && BT_MAX_VOL=$v
  v=$(settings get system ios_vol_bt_default 2>/dev/null)
  [ -n "$v" ] && [ "$v" != "null" ] && BT_DEFAULT_VOL=$v
  v=$(settings get system ios_vol_hs_max 2>/dev/null)
  [ -n "$v" ] && [ "$v" != "null" ] && HS_MAX_VOL=$v
  v=$(settings get system ios_vol_adaptive 2>/dev/null)
  [ -n "$v" ] && [ "$v" != "null" ] && ADAPTIVE_ENABLED=$v
  v=$(settings get system ios_vol_quiet_start 2>/dev/null)
  [ -n "$v" ] && [ "$v" != "null" ] && QUIET_START=$v
  v=$(settings get system ios_vol_quiet_end 2>/dev/null)
  [ -n "$v" ] && [ "$v" != "null" ] && QUIET_END=$v
  v=$(settings get system ios_vol_fade_ms 2>/dev/null)
  [ -n "$v" ] && [ "$v" != "null" ] && FADE_MS=$v
  echo "BT_MAX_VOL=$BT_MAX_VOL" > $MONITOR_CONF
  echo "BT_DEFAULT_VOL=$BT_DEFAULT_VOL" >> $MONITOR_CONF
  echo "HS_MAX_VOL=$HS_MAX_VOL" >> $MONITOR_CONF
  echo "ADAPTIVE_ENABLED=$ADAPTIVE_ENABLED" >> $MONITOR_CONF
  echo "QUIET_START=$QUIET_START" >> $MONITOR_CONF
  echo "QUIET_END=$QUIET_END" >> $MONITOR_CONF
  echo "FADE_MS=$FADE_MS" >> $MONITOR_CONF
  log "load_config: BT_MAX=$BT_MAX_VOL HS_MAX=$HS_MAX_VOL FADE=$FADE_MS"
}

get_device() {
  h2w=$(cat /sys/class/switch/h2w/state 2>/dev/null)
  [ -n "$h2w" ] && [ "$h2w" != "0" ] && echo headset && return
  for d in /sys/bus/usb/devices/*/sound/card*; do
    [ -d "$d" ] && echo usb && return 2>/dev/null
  done
  is_bt=0
  for f in /sys/class/bluetooth/*/state; do
    [ "$(cat "$f" 2>/dev/null)" = "connected" ] && { is_bt=1; break; }
  done
  if [ "$is_bt" = "1" ]; then
    bt_a2dp=$(dumpsys bluetooth_manager 2>/dev/null | grep -a -c 'A2dpStateMachine state=Connected')
    [ "$bt_a2dp" -gt "0" ] 2>/dev/null && echo bluetooth && return
  fi
  echo speaker
}

get_music_volume() {
  settings get system volume_music_speaker 2>/dev/null || echo 8
}

mute_now() {
  cmd media_session volume --set 0 2>/dev/null
  cmd audio set-volume STREAM_MUSIC 0 2>/dev/null
}

ios_ramp() {
  t=$1; d=$2
  [ "$t" -lt 0 ] 2>/dev/null && t=0
  [ "$t" -gt 16 ] 2>/dev/null && t=16
  if [ "$t" -gt 4 ] 2>/dev/null; then
    q=$((t / 4))
    [ "$q" -lt 1 ] && q=1
    cmd media_session volume --set "$q" 2>/dev/null
    sleep 0.08
    cmd media_session volume --set "$t" 2>/dev/null
    log "  ramp $d: 0 -> $q -> $t"
  elif [ "$t" -gt 0 ] 2>/dev/null; then
    cmd media_session volume --set "$t" 2>/dev/null
    log "  restore $d: $t"
  fi
}

handle_switch() {
    od=$1; nd=$2
    load_config

    # ── V4A 设备切换：已停用（旧 V4ADeviceMonitorService 已随音效页 v2.1 照搬重写删除）。
    #   新驱动 v2.0.1 + 官方 2.0.3 采用 AudioDevice + DB 设备预设，由 APP ViperService 内部自处理，
    #   不再由 volume_monitor 拉起独立切换服务。设备切换机制后续按新方案补。──

    mute_now
    log "switch: $od -> $nd"
  ov=$(get_music_volume)
  echo "$ov" > $VOL_DIR/$od
  log "  save $od: $ov"
  [ "$nd" = "bluetooth" ] && sleep 0.5 || sleep 0.5
  tgt=""
  [ -f "$VOL_DIR/$nd" ] && tgt=$(cat "$VOL_DIR/$nd")
  case $nd in
    bluetooth)
      [ -z "$tgt" ] && tgt=$BT_DEFAULT_VOL
      [ "$tgt" -gt "$BT_MAX_VOL" ] 2>/dev/null && tgt=$BT_MAX_VOL
      [ "$od" = "speaker" ] && [ -n "$ov" ] && {
        [ "$ov" -ge 14 ] 2>/dev/null && {
          m=$((ov - 2))
          [ "$m" -lt "$BT_DEFAULT_VOL" ] && m=$BT_DEFAULT_VOL
          [ "$m" -gt "$BT_MAX_VOL" ] && m=$BT_MAX_VOL
          [ "$m" -ne "$tgt" ] && { tgt=$m; log "  map: spk$ov -> bt$tgt"; }
        }
        [ "$ov" -ge 10 ] 2>/dev/null && [ "$ov" -lt 14 ] 2>/dev/null && {
          m=$((ov - 1))
          [ "$m" -lt "$BT_DEFAULT_VOL" ] && m=$BT_DEFAULT_VOL
          [ "$m" -ne "$tgt" ] && { tgt=$m; log "  map: spk$ov -> bt$tgt"; }
        }
      } ;;
    headset)
      [ -z "$tgt" ] && tgt=8
      [ "$tgt" -gt "$HS_MAX_VOL" ] 2>/dev/null && { tgt=$HS_MAX_VOL; log "  hs limit: $HS_MAX_VOL"; } ;;
    *)
      # 切换到扬声器：不强制设置音量，系统自行保持
      log "  $nd: skip volume set"
      return 0 ;;
  esac
  ios_ramp "$tgt" "$nd"
}

get_adaptive_mode() {
  [ "$ADAPTIVE_ENABLED" != "1" ] && echo normal && return
  h=$(date +%H); v=$(get_music_volume)
  [ "$h" -ge "$QUIET_START" ] 2>/dev/null || [ "$h" -lt "$QUIET_END" ] 2>/dev/null && { echo quiet; return; }
  [ "$v" -ge 12 ] 2>/dev/null && { echo noisy; return; }
  echo normal
}

main_loop() {
  log "main_loop start"
  LAST_DEV=""; LAST_ADAPTIVE=""; IDLE=0; ATICK=0; CTICK=0
  while true; do
    CD=$(get_device)
    if [ "$CD" != "$LAST_DEV" ] && [ -n "$LAST_DEV" ]; then
      IDLE=0; handle_switch "$LAST_DEV" "$CD"
    else
      IDLE=$((IDLE + 1))
    fi
    [ "$CD" = "bluetooth" ] && {
      CV=$(get_music_volume)
      [ "$CV" -gt "$BT_MAX_VOL" ] 2>/dev/null && {
        cmd media_session volume --set "$BT_MAX_VOL" 2>/dev/null
        log "  bt safe: $CV -> $BT_MAX_VOL"; CV=$BT_MAX_VOL
      }
      echo "$CV" > $VOL_DIR/bluetooth
    }
    [ "$CD" = "headset" ] && {
      CV=$(get_music_volume)
      [ "$CV" -gt "$HS_MAX_VOL" ] 2>/dev/null && {
        cmd media_session volume --set "$HS_MAX_VOL" 2>/dev/null
        log "  hs safe: $CV -> $HS_MAX_VOL"; CV=$HS_MAX_VOL
      }
      echo "$CV" > $VOL_DIR/headset
    }
    ATICK=$((ATICK + 1))
    [ "$ATICK" -ge 30 ] && {
      ATICK=0; NM=$(get_adaptive_mode)
      [ "$NM" != "$LAST_ADAPTIVE" ] && {
        echo "$NM" > $STATE_FILE
        setprop persist.vendor.audio.adaptive.mode "$NM" 2>/dev/null
        log "adaptive: ${LAST_ADAPTIVE:-init} -> $NM"; LAST_ADAPTIVE=$NM
      }
    }
    CTICK=$((CTICK + 1))
    [ "$CTICK" -ge 30 ] && {
      CTICK=0; obm=$BT_MAX_VOL; ofd=$FADE_MS; load_config
      [ "$BT_MAX_VOL" != "$obm" ] && log "config: BT_MAX $obm -> $BT_MAX_VOL"
      [ "$FADE_MS" != "$ofd" ] && {
        setprop persist.vendor.audio.volume.fade_ms "$FADE_MS" 2>/dev/null
        setprop persist.vendor.audio.volume.ramp.time.ms "$FADE_MS" 2>/dev/null
        log "config: FADE $ofd -> $FADE_MS"
      }
    }
    LAST_DEV=$CD
    [ "$CD" = "speaker" ] && sleep 0.3 || {
      [ "$IDLE" -gt 6 ] && sleep 5 || sleep 1
    }
  done
}

load_config
if [ "$1" = "daemon" ]; then
  MY_PID=$(pidof -s volume_monitor.sh 2>/dev/null || echo $$)
  log "v4.1.4 daemon PID:$MY_PID"
  while true; do main_loop; log "loop exit, restart 5s..."; sleep 5; done
else
  log "v4.1.4 normal PID:$$"
  main_loop
fi