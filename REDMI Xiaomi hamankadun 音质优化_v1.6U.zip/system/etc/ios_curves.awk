BEGIN { in_vol = 0; in_ref = 0; skip_ref = 0; ref_started = 0 }

/<indexMax>[0-9]+<\/indexMax>/ {
    gsub(/<indexMax>[0-9]+<\/indexMax>/, "<indexMax>16</indexMax>")
    print; next
}

/<reference name="FULL_SCALE_VOLUME_CURVE"/ { skip_ref = 1 }
/<reference name="SILENT_VOLUME_CURVE"/ { skip_ref = 1 }
skip_ref && /<\/reference>/ { skip_ref = 0; print; next }
skip_ref { print; next }

/<reference name="/ { in_ref = 1; ref_started = 0; print; next }
/<\/reference>/ { in_ref = 0; ref_started = 0; print; next }

/<volume deviceCategory=.*\/>/ { print; next }

/<volume deviceCategory=/ && /ref=/ { print; next }

/<volume deviceCategory=/ && !/ref=/ {
    indent = $0; gsub(/<.*/, "", indent); pt = indent "    "
    print
    printf "%s<point>0,-14400</point>\n", pt
    printf "%s<point>6,-7225</point>\n", pt
    printf "%s<point>13,-5419</point>\n", pt
    printf "%s<point>19,-4362</point>\n", pt
    printf "%s<point>25,-3612</point>\n", pt
    printf "%s<point>31,-3031</point>\n", pt
    printf "%s<point>38,-2556</point>\n", pt
    printf "%s<point>44,-2154</point>\n", pt
    printf "%s<point>50,-1806</point>\n", pt
    printf "%s<point>56,-1499</point>\n", pt
    printf "%s<point>63,-1225</point>\n", pt
    printf "%s<point>69,-976</point>\n", pt
    printf "%s<point>75,-750</point>\n", pt
    printf "%s<point>81,-541</point>\n", pt
    printf "%s<point>88,-348</point>\n", pt
    printf "%s<point>94,-168</point>\n", pt
    printf "%s<point>100,0</point>\n", pt
    in_vol = 1; next
}

/<point>/ && in_ref && !ref_started {
    indent = $0; gsub(/<point>.*/, "", indent)
    printf "%s<point>0,-14400</point>\n", indent
    printf "%s<point>6,-7225</point>\n", indent
    printf "%s<point>13,-5419</point>\n", indent
    printf "%s<point>19,-4362</point>\n", indent
    printf "%s<point>25,-3612</point>\n", indent
    printf "%s<point>31,-3031</point>\n", indent
    printf "%s<point>38,-2556</point>\n", indent
    printf "%s<point>44,-2154</point>\n", indent
    printf "%s<point>50,-1806</point>\n", indent
    printf "%s<point>56,-1499</point>\n", indent
    printf "%s<point>63,-1225</point>\n", indent
    printf "%s<point>69,-976</point>\n", indent
    printf "%s<point>75,-750</point>\n", indent
    printf "%s<point>81,-541</point>\n", indent
    printf "%s<point>88,-348</point>\n", indent
    printf "%s<point>94,-168</point>\n", indent
    printf "%s<point>100,0</point>\n", indent
    ref_started = 1; next
}

/<point>/ && (in_vol || (in_ref && ref_started)) { next }

/<\/volume>/ { in_vol = 0; print; next }

{ print }
