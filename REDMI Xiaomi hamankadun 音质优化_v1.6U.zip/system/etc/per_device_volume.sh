#!/system/bin/sh
# ============================================================
# iOS Volume Unified v3.3 — per-device 音量记忆
# 为不同输出设备分别记忆音量档位
# ============================================================

LOG="/data/local/tmp/ios_volume_unified_myron.log"
VOL_DIR="/data/local/tmp/ios_volume_devices"
mkdir -p "$VOL_DIR"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [per-device] $1" >> "$LOG"; }

get_device() {
  local route
  route=$(dumpsys audio 2>/dev/null | grep -i "STREAM_MUSIC:" | head -1)
  case "$route" in
    *SPEAKER*|*speaker*)  echo "speaker" ;;
    *HEADSET*|*headset*|*HEADPHONE*) echo "headset" ;;
    *A2DP*|*a2dp*|*BLUETOOTH*) echo "bluetooth" ;;
    *USB*|*usb*)  echo "usb" ;;
    *EARPIECE*|*earpiece*) echo "earpiece" ;;
    *) echo "speaker" ;;
  esac
}

get_volume() {
  settings get system volume_music_speaker 2>/dev/null || echo "8"
}

set_volume() {
  local vol="$1"
  if [ "$vol" -ge 0 ] && [ "$vol" -le 16 ] 2>/dev/null; then
    cmd media_session volume --set "$vol" 2>/dev/null
  fi
}

log "per-device 音量记忆服务启动 (轮询: 5s)"

LAST_DEV=""
while true; do
  CUR_DEV=$(get_device)

  # 仅在设备切换时执行操作，避免无意义的 I/O
  if [ "$CUR_DEV" != "$LAST_DEV" ] && [ -n "$LAST_DEV" ]; then
    OLD_VOL=$(get_volume)
    echo "$OLD_VOL" > "$VOL_DIR/$LAST_DEV"
    log "保存 $LAST_DEV 音量: $OLD_VOL"

    if [ -f "$VOL_DIR/$CUR_DEV" ]; then
      NEW_VOL=$(cat "$VOL_DIR/$CUR_DEV")
      set_volume "$NEW_VOL"
      log "恢复 $CUR_DEV 音量: $NEW_VOL"
    fi
  fi

  LAST_DEV="$CUR_DEV"
  sleep 5
done
