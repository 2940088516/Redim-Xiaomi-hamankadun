#!/system/bin/sh
# ============================================================
# iOS Volume Unified v3.3 — 自适应音量曲线
# 根据环境噪声级别切换模式
# ============================================================

LOG="/data/local/tmp/ios_volume_unified_myron.log"
STATE_FILE="/data/local/tmp/ios_volume_adaptive_state"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [adaptive] $1" >> "$LOG"; }

# ============================================================
# tinycap 可用性检测
# ============================================================
HAS_TINYCAP=0
if command -v tinycap >/dev/null 2>&1; then
  HAS_TINYCAP=1
  log "tinycap 可用"
else
  # 尝试常见路径
  for tincap_path in /system/bin/tinycap /vendor/bin/tinycap /system/vendor/bin/tinycap; do
    if [ -x "$tincap_path" ]; then
      HAS_TINYCAP=1
      TINYCAP_BIN="$tincap_path"
      log "tinycap 可用: $tincap_path"
      break
    fi
  done
  [ "$HAS_TINYCAP" -eq 0 ] && log "tinycap 不可用，使用音量推断模式"
fi

TINYCAP_BIN="${TINYCAP_BIN:-tinycap}"

sample_noise() {
  if [ "$HAS_TINYCAP" -eq 1 ]; then
    local tmp="/data/local/tmp/noise_sample.raw"
    # 快速采样 0.5 秒
    $TINYCAP_BIN "$tmp" -D 0 -d 0 -c 1 -r 16000 -b 16 -p 256 -t 0.5 2>/dev/null
    if [ -f "$tmp" ]; then
      local size=$(wc -c < "$tmp" 2>/dev/null || echo 0)
      rm -f "$tmp"
      echo "$size"
    else
      echo "0"
    fi
  else
    # tinycap 不可用：通过当前音量和时间推断
    # 高音量 + 白天 = noisy，低音量 + 夜间 = quiet
    local hour=$(date +%H)
    local cur_vol=8
    if command -v settings >/dev/null 2>&1; then
      cur_vol=$(settings get system volume_music_speaker 2>/dev/null || echo 8)
    fi
    cur_vol=${cur_vol:-8}

    if [ "$hour" -ge 23 ] 2>/dev/null || [ "$hour" -lt 7 ] 2>/dev/null; then
      # 夜间
      echo "3000"
    elif [ "$cur_vol" -ge 12 ] 2>/dev/null; then
      # 高音量 → 可能环境嘈杂
      echo "90000"
    else
      echo "40000"
    fi
  fi
}

switch_mode() {
  local mode="$1"
  local current=$(cat "$STATE_FILE" 2>/dev/null || echo "normal")

  [ "$current" = "$mode" ] && return

  echo "$mode" > "$STATE_FILE"

  if command -v resetprop >/dev/null 2>&1; then
    resetprop persist.vendor.audio.adaptive.mode "$mode"
  else
    setprop persist.vendor.audio.adaptive.mode "$mode"
  fi

  log "切换到 $mode 模式"
}

# 主循环
echo "normal" > "$STATE_FILE"
log "自适应音量服务启动 (tinycap=$HAS_TINYCAP)"

while true; do
  noise=$(sample_noise)

  if [ "$noise" -lt 8000 ] 2>/dev/null; then
    switch_mode "quiet"
  elif [ "$noise" -lt 80000 ] 2>/dev/null; then
    switch_mode "normal"
  else
    switch_mode "noisy"
  fi

  sleep 10
done
